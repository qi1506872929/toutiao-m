<template>
  <div>用户通知</div>
</template>

<script>
export default {
  name: 'UserNotify',
  components: {},
  props: {},
  data () {
    return {}
  },
  computed: {},
  watch: {},
  created () {},
  mounted () {},
  methods: {}
}
</script>

<style scoped></style>
