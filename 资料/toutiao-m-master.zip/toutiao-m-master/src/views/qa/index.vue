<template>
  <div class="qa-container page-container">
    <van-nav-bar
      class="page-navbar"
      title="问答"
      fixed
    />
    <h1>开发中...</h1>
  </div>
</template>

<script>

export default {
  name: 'QaPage',
  components: {
  },
  props: {},
  data () {
    return {}
  },
  computed: {},
  watch: {
  },
  created () {},
  methods: {}
}
</script>

<style scoped>
.qa-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100%;
  color: #ff6971;
}
</style>
